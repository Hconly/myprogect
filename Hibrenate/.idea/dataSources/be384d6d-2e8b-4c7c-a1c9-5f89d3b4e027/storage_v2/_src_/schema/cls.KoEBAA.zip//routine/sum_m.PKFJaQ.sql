create function sum_m(a int, b int)
  returns int
  begin
DECLARE s int;
set s = a+b;
return s;
end;

